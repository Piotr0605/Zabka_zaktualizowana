"""
Moduł do rejestracji i obsługi klientów oraz zakupów.
"""

import csv, os, random, datetime
from functools import wraps
from typing import List, Tuple

CUSTOMERS_CSV = os.path.join(os.path.dirname(__file__), '..', 'data', 'customers.csv')
DB_FOLDER = os.path.join(os.path.dirname(__file__), '..', 'DATABASE')

def exception_handler(func):
    """Obsługa wyjątków ValueError i I/O."""
    @wraps(func)
    def inner(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except (ValueError, IOError) as e:
            print(f"Wyjątek w {func.__name__}: {e}")
    return inner

def generate_id() -> str:
    """Generuje losowe 4-cyfrowe ID klienta."""
    return f"{random.randint(0, 9999):04d}"

@exception_handler
def register_customer(first_name: str, last_name: str, email: str) -> str:
    """
    Rejestruje nowego klienta, tworzy plik zakupów.
    Zwraca ID klienta.
    """
    customer_id = generate_id()
    now = datetime.datetime.now().isoformat()
    with open(CUSTOMERS_CSV, 'a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([customer_id, first_name, last_name, email, now])
    path = os.path.join(DB_FOLDER, f"{customer_id}.txt")
    open(path, 'w', encoding='utf-8').close()
    print(f"Zarejestrowano klienta {first_name} {last_name} (ID={customer_id}).")
    return customer_id

@exception_handler
def delete_customer(identifier, by='ID'):
    """
    Usuwa klienta z bazy i plik zakupów.
    :param identifier: ID lub imię/nazwisko
    """
    rows = []
    with open(CUSTOMERS_CSV, newline='', encoding='utf-8') as f:
        reader = csv.reader(f)
        rows = [r for r in reader if not (r[0]==identifier or r[1]==identifier or r[2]==identifier)]
    if len(rows) == sum(1 for _ in open(CUSTOMERS_CSV)):
        raise ValueError("Nie znaleziono klienta.")
    with open(CUSTOMERS_CSV, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerows(rows)
    path = os.path.join(DB_FOLDER, f"{identifier}.txt")
    if os.path.exists(path):
        os.remove(path)
    print(f"Usunięto klienta {identifier}.")

def purchase_decorator(func):
    """
    Dekorator: loguje każdą operację zakupu w pliku klienta.
    """
    @wraps(func)
    def wrapper(client_id: str, items: List[Tuple[str,int]]):
        result = func(client_id, items)
        log_path = os.path.join(DB_FOLDER, f"{client_id}.txt")
        with open(log_path, 'a', encoding='utf-8') as f:
            f.write(f"{datetime.datetime.now().isoformat()} -> {items}\n")
        return result
    return wrapper

@purchase_decorator
@exception_handler
def purchase_products(client_id: str, items: List[Tuple[str, int]]):
    """
    Pozwala klientowi kupić wiele produktów na raz.
    :param client_id: ID klienta
    :param items: lista krotek (product_ID, ilość)
    """
    from frog.product_manager import remove_product
    def filter_available(products):
        return list(filter(lambda x: x[1]>0, products))
    available = filter_available(items)
    if not available:
        raise ValueError("Brak dostępnych produktów w zamówieniu.")
    print(f"Klient {client_id} kupuje: {available}")
    return available
